import React, {useEffect, useMemo, useState} from 'react';
import {Alert, FlatList, Linking, SafeAreaView, StatusBar, StyleSheet, Text, TextInput, TouchableOpacity, View} from 'react-native';
import * as Contacts from 'expo-contacts';
import AsyncStorage from '@react-native-async-storage/async-storage';

const KEY_LOG='pr_avisos_log_v1';
const DEFAULT_INVOICE='Hola {nombre}. Te informamos que tu factura de PuntoRojo ya está disponible. Gracias por preferir nuestros servicios.';
const DEFAULT_DUE='Hola {nombre}. Te recordamos que mañana vence tu servicio de internet. Te invitamos a realizar tu pago a tiempo para evitar interrupciones.';

function getGroup(name='') {
  const n=name.toLowerCase().replace(/\s/g,'');
  if (/client[-_]?15$/.test(n)) return '15';
  if (/client[-_]?30$/.test(n)) return '30';
  return 'other';
}
function cleanPhone(phone='') { return phone.replace(/[^\d+]/g,'').replace(/^00/,'+'); }

export default function App() {
  const [contacts,setContacts]=useState([]);
  const [selected,setSelected]=useState({});
  const [filter,setFilter]=useState('15');
  const [query,setQuery]=useState('');
  const [loading,setLoading]=useState(false);
  const [templateType,setTemplateType]=useState('invoice');
  const [invoice,setInvoice]=useState(DEFAULT_INVOICE);
  const [due,setDue]=useState(DEFAULT_DUE);
  const [log,setLog]=useState([]);
  const [queueIndex,setQueueIndex]=useState(0);

  useEffect(()=>{ (async()=>{
    try {
      const saved=await AsyncStorage.getItem(KEY_LOG); if(saved) setLog(JSON.parse(saved));
      const t=await AsyncStorage.getItem('pr_templates_v1');
      if(t){const p=JSON.parse(t); if(p.invoice)setInvoice(p.invoice); if(p.due)setDue(p.due);}
    } catch(e) {}
  })(); },[]);

  const loadContacts=async()=>{
    setLoading(true);
    try {
      const p=await Contacts.requestPermissionsAsync();
      if(p.status!=='granted'){Alert.alert('Permiso necesario','Autoriza el acceso a contactos para importar los clientes.');return;}
      const {data}=await Contacts.getContactsAsync({fields:[Contacts.Fields.PhoneNumbers],sort:Contacts.SortTypes.FirstName});
      const rows=data.filter(c=>c.name && c.phoneNumbers?.length).map(c=>({
        id:c.id,name:c.name,phone:cleanPhone(c.phoneNumbers[0].number||''),
        group:getGroup(c.name)
      })).filter(c=>c.phone);
      setContacts(rows);
      Alert.alert('Contactos importados',`${rows.length} contactos con teléfono encontrados.`);
    } catch(e){Alert.alert('Error','No se pudieron leer los contactos.');}
    finally{setLoading(false);}
  };

  const visible=useMemo(()=>contacts.filter(c=>{
    const match=filter==='all'||(filter==='other'?c.group==='other':c.group===filter);
    return match && (c.name.toLowerCase().includes(query.toLowerCase())||c.phone.includes(query));
  }),[contacts,filter,query]);

  const chosen=contacts.filter(c=>selected[c.id]);
  const message=(c)=> (templateType==='invoice'?invoice:due).replaceAll('{nombre}',c.name.replace(/[-_ ]*Client[-_ ]*(15|30)$/i,'').trim()||c.name);
  const saveTemplates=async()=>{await AsyncStorage.setItem('pr_templates_v1',JSON.stringify({invoice,due}));Alert.alert('Guardado','Tus mensajes quedaron guardados.');};
  const addLog=async(c)=>{
    const item={id:Date.now().toString(),name:c.name,phone:c.phone,type:templateType,at:new Date().toISOString()};
    const next=[item,...log]; setLog(next); await AsyncStorage.setItem(KEY_LOG,JSON.stringify(next));
  };
  const sendOne=async(c)=>{
    const phone=c.phone.replace(/\D/g,'');
    if(phone.length<8){Alert.alert('Número inválido',`Revisa el teléfono de ${c.name}.`);return;}
    const url=`https://wa.me/${phone}?text=${encodeURIComponent(message(c))}`;
    try { if(await Linking.canOpenURL(url)){await Linking.openURL(url); await addLog(c);} else Alert.alert('WhatsApp no disponible','Instala o activa WhatsApp en este teléfono.');}
    catch(e){Alert.alert('No se pudo abrir WhatsApp','Comprueba el número y vuelve a intentar.');}
  };
  const startQueue=()=>{if(!chosen.length){Alert.alert('Selecciona clientes','Marca al menos un cliente.');return;} setQueueIndex(0); Alert.alert('Envío en cascada',`Se abrirá WhatsApp para ${chosen.length} clientes, uno por uno. Debes tocar Enviar en WhatsApp y regresar aquí para continuar.`);};
  const nextQueue=async()=>{
    if(!chosen.length)return;
    const c=chosen[queueIndex];
    if(!c){Alert.alert('Proceso terminado','Ya recorriste todos los clientes seleccionados.');return;}
    await sendOne(c);
    setQueueIndex(i=>i+1);
  };
  const toggle=(id)=>setSelected(s=>({...s,[id]:!s[id]}));
  const selectVisible=()=>setSelected(s=>({...s,...Object.fromEntries(visible.map(c=>[c.id,true]))}));
  const clearSelection=()=>setSelected({});

  const renderContact=({item})=>(
    <TouchableOpacity style={styles.contact} onPress={()=>toggle(item.id)}>
      <View style={[styles.check,selected[item.id]&&styles.checked]}><Text style={styles.checkText}>{selected[item.id]?'✓':''}</Text></View>
      <View style={{flex:1}}><Text style={styles.contactName}>{item.name}</Text><Text style={styles.phone}>{item.phone}</Text></View>
      <Text style={styles.group}>{item.group==='other'?'OTRO':`CLIENT-${item.group}`}</Text>
    </TouchableOpacity>
  );

  return <SafeAreaView style={styles.safe}>
    <StatusBar barStyle="dark-content"/>
    <View style={styles.header}><Text style={styles.brand}>PuntoRojo <Text style={{color:'#e31b23'}}>Avisos</Text></Text><Text style={styles.sub}>Avisos de facturación por WhatsApp</Text></View>
    <View style={styles.actions}>
      <TouchableOpacity style={styles.primary} onPress={loadContacts} disabled={loading}><Text style={styles.primaryText}>{loading?'Cargando...':'Importar contactos del teléfono'}</Text></TouchableOpacity>
    </View>
    <View style={styles.tabs}>
      {[['15','Client-15'],['30','Client-30'],['all','Todos'],['other','Otros']].map(([v,l])=><TouchableOpacity key={v} onPress={()=>setFilter(v)} style={[styles.tab,filter===v&&styles.tabActive]}><Text style={[styles.tabText,filter===v&&styles.tabTextActive]}>{l}</Text></TouchableOpacity>)}
    </View>
    <TextInput style={styles.search} placeholder="Buscar cliente o teléfono..." value={query} onChangeText={setQuery}/>
    <View style={styles.rowBetween}><Text style={styles.count}>{visible.length} contactos · {chosen.length} seleccionados</Text><View style={{flexDirection:'row',gap:12}}><Text onPress={selectVisible} style={styles.link}>Seleccionar visibles</Text><Text onPress={clearSelection} style={styles.link}>Limpiar</Text></View></View>
    <FlatList data={visible} keyExtractor={x=>x.id} renderItem={renderContact} ListEmptyComponent={<Text style={styles.empty}>Importa tus contactos. Los nombres terminados en Client-15 o Client-30 se agrupan automáticamente.</Text>}/>
    <View style={styles.bottom}>
      <View style={styles.tabs}><TouchableOpacity onPress={()=>setTemplateType('invoice')} style={[styles.tab,templateType==='invoice'&&styles.tabActive]}><Text style={[styles.tabText,templateType==='invoice'&&styles.tabTextActive]}>Factura generada</Text></TouchableOpacity><TouchableOpacity onPress={()=>setTemplateType('due')} style={[styles.tab,templateType==='due'&&styles.tabActive]}><Text style={[styles.tabText,templateType==='due'&&styles.tabTextActive]}>Vence mañana</Text></TouchableOpacity></View>
      <TextInput multiline style={styles.template} value={templateType==='invoice'?invoice:due} onChangeText={templateType==='invoice'?setInvoice:setDue}/>
      <View style={styles.rowBetween}><Text onPress={saveTemplates} style={styles.link}>Guardar mensaje</Text><Text style={styles.count}>Historial: {log.length}</Text></View>
      <View style={styles.rowButtons}>
        <TouchableOpacity style={styles.secondary} onPress={startQueue}><Text style={styles.secondaryText}>Preparar cascada</Text></TouchableOpacity>
        <TouchableOpacity style={styles.primarySmall} onPress={nextQueue}><Text style={styles.primaryText}>Abrir siguiente ({Math.min(queueIndex+1,chosen.length)}/{chosen.length})</Text></TouchableOpacity>
      </View>
      <Text style={styles.note}>WhatsApp se abre para cada cliente. Revisa el mensaje y pulsa Enviar; luego regresa y toca “Abrir siguiente”.</Text>
    </View>
  </SafeAreaView>;
}

const styles=StyleSheet.create({
 safe:{flex:1,backgroundColor:'#f5f6f8'},header:{padding:18,backgroundColor:'#fff'},brand:{fontSize:25,fontWeight:'900',color:'#171717'},sub:{color:'#666',marginTop:3},
 actions:{paddingHorizontal:14,paddingTop:12},primary:{backgroundColor:'#d71920',padding:13,borderRadius:10,alignItems:'center'},primaryText:{color:'#fff',fontWeight:'800'},
 tabs:{flexDirection:'row',gap:6,padding:10},tab:{paddingVertical:9,paddingHorizontal:12,borderRadius:20,backgroundColor:'#e8e9ed'},tabActive:{backgroundColor:'#20242b'},tabText:{fontSize:12,color:'#343840',fontWeight:'700'},tabTextActive:{color:'#fff'},
 search:{backgroundColor:'#fff',marginHorizontal:14,padding:12,borderRadius:10},rowBetween:{flexDirection:'row',justifyContent:'space-between',alignItems:'center',paddingHorizontal:14,paddingVertical:9},count:{fontSize:12,color:'#666'},link:{fontSize:12,color:'#c4161c',fontWeight:'800'},
 contact:{flexDirection:'row',alignItems:'center',padding:12,marginHorizontal:12,marginVertical:3,backgroundColor:'#fff',borderRadius:10,gap:10},check:{width:22,height:22,borderWidth:1.5,borderColor:'#999',borderRadius:6,alignItems:'center',justifyContent:'center'},checked:{backgroundColor:'#d71920',borderColor:'#d71920'},checkText:{color:'#fff',fontWeight:'900'},contactName:{fontWeight:'700',color:'#202124'},phone:{color:'#777',fontSize:12,marginTop:2},group:{fontSize:9,color:'#c4161c',fontWeight:'900'},empty:{textAlign:'center',color:'#777',padding:25},
 bottom:{backgroundColor:'#fff',paddingBottom:8,borderTopWidth:1,borderColor:'#e3e4e8'},template:{backgroundColor:'#f5f6f8',marginHorizontal:14,minHeight:65,maxHeight:90,padding:10,borderRadius:9,textAlignVertical:'top',fontSize:12},rowButtons:{flexDirection:'row',gap:8,paddingHorizontal:14},secondary:{flex:1,borderWidth:1,borderColor:'#d71920',padding:12,borderRadius:9,alignItems:'center'},secondaryText:{color:'#c4161c',fontWeight:'800',fontSize:12},primarySmall:{flex:1,backgroundColor:'#d71920',padding:12,borderRadius:9,alignItems:'center'},note:{fontSize:10,color:'#777',paddingHorizontal:14,paddingTop:7}
});
