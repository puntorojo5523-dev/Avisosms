# PuntoRojo Avisos v1.1

Proyecto inicial Android con Expo/React Native.

## Incluye
- Importación de contactos del teléfono con permiso del usuario.
- Agrupación por sufijos `Client-15`, `Client15`, `Client-30` y `Client30`.
- Selección individual o masiva de contactos.
- Plantillas editables para factura generada y vencimiento mañana.
- Apertura de WhatsApp con el texto preparado, un cliente por vez.
- Historial local de conversaciones abiertas para aviso.
- Configuración EAS para compilar APK de prueba.

## Importante
La app no puede leer directamente las etiquetas internas de WhatsApp Business ni confirmar que un mensaje fue enviado. El historial registra que se abrió WhatsApp para preparar el aviso; el usuario debe pulsar Enviar. La integración automática con WispHub y los envíos oficiales en segundo plano quedan para una fase posterior.

## Compilar
1. Sube el contenido de este ZIP a un repositorio GitHub.
2. Crea una cuenta/proyecto en Expo y genera un token EAS.
3. En GitHub: Settings > Secrets and variables > Actions > New repository secret.
4. Nombre: `EXPO_TOKEN`; valor: tu token de Expo.
5. En Actions ejecuta `Build PuntoRojo Avisos APK`.
6. También puedes compilar desde un entorno con Node: `npm install`, `npm install -g eas-cli`, `eas build --platform android --profile preview`.

Este paquete es código fuente; todavía no es una APK instalada ni compilada.
